# =============================================================================
# emmc_autoscript.cmd — DBAI Internal eMMC Direct Bootloader (Vendor U-Boot)
# =============================================================================
# Dipanggil oleh aml_autoscript (run start_emmc_autoscript) saat Armbian
# di-install permanen ke chip flash eMMC internal dan MicroSD dilepas.
#
# Standar DBAI:
#   1. Load address aman 0x01080000 (bebas crash RAM 1GB)
#   2. Memuat vmlinuz-${KERNEL} dan uInitrd-${KERNEL} dari eMMC (tanpa file kembar)
#   3. Membaca uEnv.txt dari partisi boot eMMC
#   4. Fallback chainload u-boot.emmc jika ada box yang membutuhkannya
#
# Compile: mkimage -C none -A arm64 -T script -d emmc_autoscript.cmd emmc_autoscript
# =============================================================================
echo "DBAI: start amlogic vendor u-boot (emmc_autoscript)"

# Fallback chainload jika ada u-boot.emmc
if fatload mmc 1 0x1000000 u-boot.emmc; then go 0x1000000; fi;
if fatload mmc 2 0x1000000 u-boot.emmc; then go 0x1000000; fi;

setenv loadaddr 0x01080000
setenv env_addr 0x01080000
setenv dtb_addr 0x1000000
setenv kernel_addr 0x11000000
setenv initrd_addr 0x15000000

setenv boot_start 'booti ${kernel_addr} ${initrd_addr} ${dtb_addr}'
setenv addmac 'if printenv mac; then setenv bootargs ${bootargs} mac=${mac}; elif printenv eth_mac; then setenv bootargs ${bootargs} mac=${eth_mac}; elif printenv ethaddr; then setenv bootargs ${bootargs} mac=${ethaddr}; fi'

# Pindai eMMC (mmc 1 untuk S905X/GXL, mmc 2 untuk beberapa varian G12A/SM1)
for emmc_dev in 1 2 ; do
	if test -e mmc ${emmc_dev} uEnv.txt; then
		if fatload mmc ${emmc_dev} ${env_addr} uEnv.txt; then
			env import -t ${env_addr} ${filesize}
			setenv bootargs ${APPEND}
			run addmac
			if fatload mmc ${emmc_dev} ${kernel_addr} vmlinuz-${KERNEL}; then
				if fatload mmc ${emmc_dev} ${initrd_addr} uInitrd-${KERNEL}; then
					if fatload mmc ${emmc_dev} ${dtb_addr} ${FDT}; then
						fdt addr ${dtb_addr}
						run boot_start
					fi
				fi
			fi
		fi
	fi
done
