setenv dtb_addr 0x01000000
setenv env_addr 0x01080000
setenv kernel_addr 0x11000000
setenv initrd_addr 0x15000000
setenv boot_start 'booti ${kernel_addr} ${initrd_addr} ${dtb_addr}'
setenv addmac 'if printenv mac; then setenv bootargs ${bootargs} mac=${mac}; elif printenv eth_mac; then setenv bootargs ${bootargs} mac=${eth_mac}; elif printenv ethaddr; then setenv bootargs ${bootargs} mac=${ethaddr}; fi'

for devnum in "1 2 0"; do
	if fatload mmc ${devnum} 0x01000000 u-boot.emmc; then go 0x01000000; fi;
	if fatload mmc ${devnum} ${env_addr} uEnv.txt && env import -t ${env_addr} ${filesize}; then
		setenv bootargs ${APPEND};
		run addmac;
		if test "${FDT}" = "" || test "${FDT}" = "auto"; then
			if test "${aml_dt}" = "gxl_p212_1g" || test "${aml_dt}" = "gxl_p212_2g"; then setenv FDT "/dtb/amlogic/meson-gxl-s905x-b860h.dtb"; fi;
			if test "${aml_dt}" = "g12a_u212_2g" || test "${aml_dt}" = "g12a_u212_4g"; then setenv FDT "/dtb/amlogic/meson-g12a-b860h-v5.dtb"; fi;
			if test "${aml_dt}" = "sm1_ac213_4g" || test "${aml_dt}" = "sm1_ac213_2g"; then setenv FDT "/dtb/amlogic/meson-sm1-x96-max-plus.dtb"; fi;
			if test "${aml_dt}" = "s4_s905w2_2g" || test "${soc}" = "s4"; then setenv FDT "/dtb/amlogic/meson-s4-s905w2-generic.dtb"; fi;
		fi;
		if test "${KERNEL}" != ""; then
			setenv LINUX "/vmlinuz-${KERNEL}";
			setenv INITRD "/uInitrd-${KERNEL}";
		fi;
		if test "${LINUX}" = ""; then setenv LINUX "/vmlinuz-6.1.66-DBAI"; fi;
		if test "${INITRD}" = ""; then setenv INITRD "/uInitrd-6.1.66-DBAI"; fi;
		if test ! -e mmc ${devnum} ${LINUX}; then
			if test -e mmc ${devnum} /zImage; then setenv LINUX "/zImage"; fi;
			if test -e mmc ${devnum} /vmlinuz; then setenv LINUX "/vmlinuz"; fi;
		fi;
		if test ! -e mmc ${devnum} ${INITRD}; then
			if test -e mmc ${devnum} /uInitrd; then setenv INITRD "/uInitrd"; fi;
		fi;
		if fatload mmc ${devnum} ${kernel_addr} ${LINUX}; then
			if fatload mmc ${devnum} ${initrd_addr} ${INITRD}; then
				if fatload mmc ${devnum} ${dtb_addr} ${FDT}; then
					fdt addr ${dtb_addr};
					run boot_start;
				fi;
			fi;
		fi;
	fi;
done;
