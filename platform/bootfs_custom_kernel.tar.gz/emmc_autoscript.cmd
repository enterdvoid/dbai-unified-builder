if fatload mmc 1 0x1000000 u-boot.emmc; then go 0x1000000; fi;
setenv dtb_addr 0x1000000
setenv kernel_addr 0x11000000
setenv initrd_addr 0x15000000
setenv boot_start booti ${kernel_addr} ${initrd_addr} ${dtb_addr}
setenv addmac 'if printenv mac; then setenv bootargs ${bootargs} mac=${mac}; elif printenv eth_mac; then setenv bootargs ${bootargs} mac=${eth_mac}; elif printenv ethaddr; then setenv bootargs ${bootargs} mac=${ethaddr}; fi'
if test "${LINUX}" = ""; then setenv LINUX "/zImage"; fi;
if test "${INITRD}" = ""; then setenv INITRD "/uInitrd"; fi;
setenv env_addr 0x44000000
if fatload mmc 1 ${env_addr} uEnv.txt; then echo "loaded uEnv via 0x44000000"; else setenv env_addr 0x10400000; fatload mmc 1 ${env_addr} uEnv.txt; fi;
env import -t ${env_addr} ${filesize};
setenv bootargs ${APPEND};
if fatload mmc 1 ${kernel_addr} ${LINUX}; then if fatload mmc 1 ${initrd_addr} ${INITRD}; then if fatload mmc 1 ${dtb_addr} ${FDT}; then run addmac; run boot_start; fi; fi; fi;
