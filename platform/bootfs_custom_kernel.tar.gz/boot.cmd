# =============================================================================
# boot.cmd — DBAI Mainline U-Boot Script (TIDAK DIGUNAKAN di Vendor U-Boot)
# File ini HANYA untuk referensi jika suatu hari chainloading ke mainline
# =============================================================================
# Compile  : mkimage -C none -A arm -T script -d boot.cmd boot.scr
# =============================================================================
echo "Start AMLOGIC mainline U-boot"
if printenv bootfromsd; then exit; fi;
setenv loadaddr "0x01080000"
test "${kernel_addr_r}" = "" && setenv kernel_addr_r 0x11000000
test "${ramdisk_addr_r}" = "" && setenv ramdisk_addr_r 0x15000000
test "${fdt_addr_r}" = "" && setenv fdt_addr_r 0x1000000
setenv l_mmc "0 1 2 3"
for devtype in "usb mmc" ; do
	if test "${devtype}" = "mmc"; then
		setenv l_mmc "1"
	fi
	for devnum in ${l_mmc} ; do
		if test -e ${devtype} ${devnum} uEnv.txt; then
			load ${devtype} ${devnum} ${loadaddr} uEnv.txt
			env import -t ${loadaddr} ${filesize}
			setenv bootargs ${APPEND}
			if printenv mac; then
				setenv bootargs ${bootargs} mac=${mac}
			elif printenv eth_mac; then
				setenv bootargs ${bootargs} mac=${eth_mac}
			elif printenv ethaddr; then
				setenv bootargs ${bootargs} mac=${ethaddr}
			fi
			if load ${devtype} ${devnum} ${kernel_addr_r} vmlinuz-${KERNEL}; then
				if load ${devtype} ${devnum} ${ramdisk_addr_r} uInitrd-${KERNEL}; then
					if load ${devtype} ${devnum} ${fdt_addr_r} ${FDT}; then
						fdt addr ${fdt_addr_r}
						booti ${kernel_addr_r} ${ramdisk_addr_r} ${fdt_addr_r}
					fi
				fi
			fi
		fi
	done
done
