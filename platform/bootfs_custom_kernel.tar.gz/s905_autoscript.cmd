echo ">> [DBAI] Starting Amlogic Boot Engine..."
if fatload mmc 0 ${loadaddr} boot_android; then if test ${ab} = 0; then setenv ab 1; saveenv; exit; else setenv ab 0; saveenv; fi; fi;
if fatload usb 0 ${loadaddr} boot_android; then if test ${ab} = 0; then setenv ab 1; saveenv; exit; else setenv ab 0; saveenv; fi; fi;
if fatload mmc 0 0x01000000 u-boot.ext; then go 0x01000000; fi;
if fatload usb 0 0x01000000 u-boot.ext; then go 0x01000000; fi;
setenv loadaddr 0x01080000
setenv kernel_addr_r 0x11000000
setenv ramdisk_addr_r 0x15000000
setenv fdt_addr_r 0x01000000
setenv l_mmc "0"
for devtype in "mmc usb" ; do
	if test "${devtype}" = "usb"; then
		echo ">> [DBAI] Scanning USB storage...";
		setenv l_mmc "0 1 2 3";
	fi;
	for devnum in ${l_mmc} ; do
		if test -e ${devtype} ${devnum} uEnv.txt; then
			echo ">> [DBAI] Found uEnv.txt on ${devtype} ${devnum}";
			if fatload ${devtype} ${devnum} 0x02000000 boot.bmp; then bmp display 0x02000000; fi;
			fatload ${devtype} ${devnum} ${loadaddr} uEnv.txt;
			env import -t ${loadaddr} ${filesize};
			setenv bootargs ${APPEND};
			if printenv mac; then setenv bootargs ${bootargs} mac=${mac}; elif printenv eth_mac; then setenv bootargs ${bootargs} mac=${eth_mac}; elif printenv ethaddr; then setenv bootargs ${bootargs} mac=${ethaddr}; fi;
			if test "${FDT}" = "" || test "${FDT}" = "auto"; then
				echo ">> [DBAI] Auto-detecting DTB for board...";
				if test "${aml_dt}" = "gxl_p212_1g" || test "${aml_dt}" = "gxl_p212_2g"; then setenv FDT "/dtb/amlogic/meson-gxl-s905x-b860h.dtb"; fi;
				if test "${aml_dt}" = "g12a_u212_2g" || test "${aml_dt}" = "g12a_u212_4g"; then setenv FDT "/dtb/amlogic/meson-g12a-b860h-v5.dtb"; fi;
				if test "${aml_dt}" = "sm1_ac213_4g" || test "${aml_dt}" = "sm1_ac213_2g"; then setenv FDT "/dtb/amlogic/meson-sm1-x96-max-plus.dtb"; fi;
				if test "${aml_dt}" = "s4_s905w2_2g" || test "${soc}" = "s4"; then setenv FDT "/dtb/amlogic/meson-s4-s905w2-generic.dtb"; fi;
			fi;
			if test "${KERNEL}" != ""; then
				setenv LINUX "/vmlinuz-${KERNEL}";
				setenv INITRD "/uInitrd-${KERNEL}";
			fi;
			if test "${LINUX}" = ""; then setenv LINUX "/vmlinuz-6.1.66-DBAI"; fi;
			if test "${INITRD}" = ""; then setenv INITRD "/uInitrd-6.1.66-DBAI"; fi;
			if test ! -e ${devtype} ${devnum} ${LINUX}; then
				echo ">> [DBAI] Notice: ${LINUX} not found, searching fallback...";
				if test -e ${devtype} ${devnum} /zImage; then setenv LINUX "/zImage"; fi;
				if test -e ${devtype} ${devnum} /vmlinuz; then setenv LINUX "/vmlinuz"; fi;
			fi;
			if test ! -e ${devtype} ${devnum} ${INITRD}; then
				if test -e ${devtype} ${devnum} /uInitrd; then setenv INITRD "/uInitrd"; fi;
			fi;
			echo ">> [DBAI] Loading Kernel: ${LINUX}";
			if fatload ${devtype} ${devnum} ${kernel_addr_r} ${LINUX}; then
				echo ">> [DBAI] Loading Ramdisk: ${INITRD}";
				if fatload ${devtype} ${devnum} ${ramdisk_addr_r} ${INITRD}; then
					echo ">> [DBAI] Loading Device Tree: ${FDT}";
					if fatload ${devtype} ${devnum} ${fdt_addr_r} ${FDT}; then
						fdt addr ${fdt_addr_r};
						echo ">> [DBAI] Executing booti directly...";
						booti ${kernel_addr_r} ${ramdisk_addr_r} ${fdt_addr_r};
					fi;
				fi;
			fi;
		fi;
	done;
done;
