# ============================================================================
# s905_autoscript.cmd — DBAI Smart Adaptive Resolver
# ============================================================================
# Dipanggil oleh aml_autoscript via switch_bootmode hook.
# Skrip ini membaca uEnv.txt, merakit bootargs, lalu memuat kernel + initrd
# + DTB dan booti ke Linux.
#
# PERUBAHAN KUNCI:
#   1. Load address dipaksa ke 0x01080000 (aman RAM 512MB-4GB, fix crash B860H V1)
#   2. Kernel dimuat dari vmlinuz-${KERNEL} dan ramdisk dari uInitrd-${KERNEL},
#      dimana variabel KERNEL diatur di uEnv.txt. Ini menghilangkan kebutuhan
#      file duplikat zImage dan uInitrd di partisi FAT32 (hemat ~30MB).
#   3. UUID rootfs HANYA ada di uEnv.txt, TIDAK di-hardcode di sini.
#
# Compile  : mkimage -C none -A arm64 -T script -d s905_autoscript.cmd s905_autoscript
# ============================================================================
echo "DBAI: start amlogic vendor u-boot (s905_autoscript)"

# --- Guard: jika ada boot_android, toggle ab flag lalu exit ke Android ---
if fatload mmc 0 ${loadaddr} boot_android; then if test ${ab} = 0; then setenv ab 1; saveenv; exit; else setenv ab 0; saveenv; fi; fi;
if fatload usb 0 ${loadaddr} boot_android; then if test ${ab} = 0; then setenv ab 1; saveenv; exit; else setenv ab 0; saveenv; fi; fi;

# --- Paksa load address aman untuk semua varian RAM (512MB-4GB) ---
setenv loadaddr 0x01080000
setenv kernel_addr_r 0x11000000
setenv ramdisk_addr_r 0x15000000
setenv fdt_addr_r 0x1000000

# --- Scan MicroSD (mmc 0) lalu USB, cari uEnv.txt, rakit boot ---
setenv l_mmc "0"
for devtype in "mmc usb" ; do if test "${devtype}" = "usb"; then echo "DBAI: scanning usb..."; setenv l_mmc "0 1 2 3"; fi; for devnum in ${l_mmc} ; do if test -e ${devtype} ${devnum} uEnv.txt; then fatload ${devtype} ${devnum} ${loadaddr} uEnv.txt; env import -t ${loadaddr} ${filesize}; setenv bootargs ${APPEND}; if printenv mac; then setenv bootargs ${bootargs} mac=${mac}; elif printenv eth_mac; then setenv bootargs ${bootargs} mac=${eth_mac}; fi; if fatload ${devtype} ${devnum} ${kernel_addr_r} vmlinuz-${KERNEL}; then if fatload ${devtype} ${devnum} ${ramdisk_addr_r} uInitrd-${KERNEL}; then if fatload ${devtype} ${devnum} ${fdt_addr_r} ${FDT}; then fdt addr ${fdt_addr_r}; booti ${kernel_addr_r} ${ramdisk_addr_r} ${fdt_addr_r}; fi; fi; fi; fi; done; done;
