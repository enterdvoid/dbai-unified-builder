# DBAI Linux Universal Multi-Boot Hook (AML S9xx Series)
# Dual-hook: supports both standard 'bootcmd' and vendor-custom 'switch_bootmode' (ZTE/Fiberhome)

setenv bootcmd 'run start_autoscript; run storeboot'
setenv switch_bootmode 'run start_autoscript; run storeboot'

setenv start_autoscript 'if mmcinfo; then run start_mmc_autoscript; fi; if usb start; then run start_usb_autoscript; fi; run start_emmc_autoscript'
setenv start_mmc_autoscript 'if fatload mmc 0 0x01080000 s905_autoscript; then autoscr 0x01080000; fi;'
setenv start_usb_autoscript 'for usbdev in 0 1 2 3; do if fatload usb ${usbdev} 0x01080000 s905_autoscript; then autoscr 0x01080000; fi; done'
setenv start_emmc_autoscript 'for edev in 1 2; do if fatload mmc ${edev} 0x01080000 emmc_autoscript; then autoscr 0x01080000; fi; done'

setenv upgrade_step 2
saveenv
sleep 1
reboot
